password = input('Enter the password:')

if password == 'prospero':
    print('password accepted.')

else:
    print('Sorry, that is the wrong password.')
