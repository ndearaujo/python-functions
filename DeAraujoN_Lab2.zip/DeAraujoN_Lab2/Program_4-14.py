hours = int(input('Enter the hours worked this week: '))

pay_rate = float(input('Enter the hourly pay rate: '))

gross_pay = hours * pay_rate

print('Gross pay: $', format(gross_pay, ',.2f'))
