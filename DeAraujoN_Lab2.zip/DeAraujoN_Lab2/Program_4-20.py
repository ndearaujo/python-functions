num_steps = 6

for r in range(num_steps):
    for c in range(r):
        print(' ', end='')
        print(' ', end='')
    print('#')
