for x in range(5):
    print('Hello world')
