print('I will display the numbers 1 thought 5.')
for num in [1, 2, 3, 5, 5]:
    print(num)
