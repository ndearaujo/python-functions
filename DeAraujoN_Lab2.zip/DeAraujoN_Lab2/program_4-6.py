for name in ['winken', 'Blinken', 'Nod']:
    print(name)
